package main

import (
	"bufio"
	"errors"
	"fmt"
	"math/rand"
	"os"
	"sort"
	"strconv"
	"strings"
	"time"
)

func main() {
	rand.Seed(time.Now().Unix())
	planTypes := []string{"fcfs", "rr", "sjf", "все", "all"}
	scanner := bufio.NewScanner(os.Stdin)

	fmt.Println("Введите тип планирования (FCFS, SJF, RR, все, all): ")

	typ, err := ReadString(scanner)
	if err != nil {
		fmt.Println("Ошибка:", err)
		return
	}

	if !SliceContains(planTypes, strings.ToLower(typ)) {
		fmt.Println("Неправильный тип")
		return
	}

	fmt.Println("Введите количество процессов (3): ")

	processCount, err := ReadInt(scanner)
	if err != nil {
		fmt.Println("Неверный ввод:", err.Error())
		return
	}

	if processCount < 1 {
		fmt.Println("Количество процессов не может быть меньше 1")
		return
	}

	fmt.Println("Введите максимальное количество квантов (15): ")

	maxQuant, err := ReadInt(scanner)
	if err != nil {
		fmt.Println("Неверный ввод:", err.Error())
		return
	}

	if maxQuant < 1 {
		fmt.Println("Количество квантов не может быть меньше 1")
		return
	}

	plan := map[int]int{}
	for i := 0; i < processCount; i++ {
		plan[i] = rand.Int()%maxQuant + 1
	}

	rrQuants := 0
	if strings.ToLower(typ) == "rr" || strings.ToLower(typ) == "все" || strings.ToLower(typ) == "all" {
		bestQuant, smallestTime := calcBestRRQuantAndTime(plan, maxQuant)
		fmt.Println("Самое оптимизированное количество квантов на процесс для RR", bestQuant, "при среднем времени ожидания", smallestTime)
		fmt.Println("Введите количество квантов на процесс для планирования RR (Round Robin): ")
		rrQuants, err = ReadInt(scanner)
		if err != nil {
			fmt.Println("Неверный ввод:", err.Error())
			return
		}

		if maxQuant < 1 {
			fmt.Println("Количество квантов не может быть меньше 1")
			return
		}
	}

	switch strings.ToLower(typ) {
	case "fcfs":
		FCFS(plan)
	case "rr":
		RR(plan, rrQuants)
		RRSJF(plan, rrQuants)
	case "sjf":
		SJF(plan)
	case "все":
	case "all":
		FCFS(plan)
		SJF(plan)
		RR(plan, rrQuants)
		RRSJF(plan, rrQuants)
	default:
		break
	}
}

func GetSeparatorLength(plan map[int]int) int {
	length := 0
	for _, v := range plan {
		length += v
	}

	return length + 3
}

func FCFS(plan map[int]int) {
	var fullExecTime float32 = 0
	var waitTime float32 = 0
	separatorlength := GetSeparatorLength(plan)
	execTime := 0

	fmt.Println(strings.Repeat("=", separatorlength))
	fmt.Println("FCFS")
	fmt.Println(strings.Repeat("=", separatorlength))

	for i := 0; i < len(plan); i++ {
		fmt.Print("P", i, " ")

		planString := ""

		execTime += plan[i]
		for j := 0; j < i; j++ {
			waitTime += float32(plan[j])
			planString += strings.Repeat("-", plan[j])
		}

		planString += strings.Repeat("+", plan[i])

		for j := i + 1; j < len(plan); j++ {
			planString += strings.Repeat("-", plan[j])
		}

		fullExecTime += calcFullRunTime(planString)
		fmt.Println(planString)
	}

	fmt.Println(strings.Repeat("=", separatorlength))
	fmt.Println("Время ожидания:", waitTime)
	fmt.Println("Время исполнения:", execTime)
	fmt.Println("Среднее время ожидания:", waitTime/float32(len(plan)))
	fmt.Println("Среднее время исполнения:", fullExecTime/float32(len(plan)))
}

func RR(planOriginal map[int]int, quantCount int) {
	plan := make(map[int]int, len(planOriginal))
	for i, v := range planOriginal {
		plan[i] = v
	}

	length := float32(len(plan))
	separatorlength := GetSeparatorLength(plan)

	fmt.Println(strings.Repeat("=", separatorlength))
	fmt.Println("RR")
	fmt.Println(strings.Repeat("=", separatorlength))

	var fullExecTime float32 = 0
	var waitTime float32 = 0
	planStrings := make(map[int]string, len(plan))
	maxLen := 0

	for len(plan) != 0 {
		keys := make([]int, 0, len(plan))
		for key := range plan {
			keys = append(keys, key)
		}

		sort.SliceStable(keys, func(i, j int) bool {
			return keys[i] < keys[j]
		})

		for _, key := range keys {
			if plan[key] > quantCount {
				planStrings[key] += strings.Repeat("+", quantCount)
				for k := range plan {
					if k != key {
						planStrings[k] += strings.Repeat("-", quantCount)
					}
				}

				plan[key] -= quantCount
			} else {
				planStrings[key] += strings.Repeat("+", plan[key])
				for k := range plan {
					if k != key {
						planStrings[k] += strings.Repeat("-", plan[key])
					}
				}

				delete(plan, key)
			}

			maxLen = len(planStrings[key])
		}
	}

	for key := range planStrings {
		planStrings[key] += strings.Repeat("-", maxLen-len(planStrings[key]))
	}

	for i := 0; i < len(planStrings); i++ {
		fmt.Print("P", i, " ")
		fmt.Println(planStrings[i])
		waitTime += calcWaitTime(planStrings[i])
		fullExecTime += calcFullRunTime(planStrings[i])
	}

	fmt.Println(strings.Repeat("=", separatorlength))
	fmt.Println("Время ожидания:", waitTime)
	fmt.Println("Время исполнения:", maxLen)
	fmt.Println("Среднее время ожидания:", waitTime/length)
	fmt.Println("Среднее время исполнения:", fullExecTime/length)
	fmt.Println(strings.Repeat("=", separatorlength))
}

func RRSJF(planOriginal map[int]int, quantCount int) {
	plan := make(map[int]int, len(planOriginal))
	for i, v := range planOriginal {
		plan[i] = v
	}

	length := float32(len(plan))
	separatorlength := GetSeparatorLength(plan)

	fmt.Println(strings.Repeat("=", separatorlength))
	fmt.Println("RR + SJF")
	fmt.Println(strings.Repeat("=", separatorlength))

	var fullExecTime float32 = 0
	var waitTime float32 = 0
	planStrings := make(map[int]string, len(plan))
	maxLen := 0

	keys := make([]int, 0, len(plan))

	for key := range plan {
		keys = append(keys, key)
	}

	for len(plan) != 0 {
		sort.SliceStable(keys, func(i, j int) bool {
			return plan[keys[i]] < plan[keys[j]]
		})

		for _, key := range keys {
			if plan[key] > quantCount {
				planStrings[key] += strings.Repeat("+", quantCount)
				for k := range plan {
					if k != key {
						planStrings[k] += strings.Repeat("-", quantCount)
					}
				}

				plan[key] -= quantCount
			} else {
				planStrings[key] += strings.Repeat("+", plan[key])
				for k := range plan {
					if k != key {
						planStrings[k] += strings.Repeat("-", plan[key])
					}
				}

				delete(plan, key)
			}

			maxLen = len(planStrings[key])
		}
	}

	sort.SliceStable(keys, func(i, j int) bool {
		return keys[i] < keys[j]
	})

	for key := range planStrings {
		planStrings[key] += strings.Repeat("-", maxLen-len(planStrings[key]))
	}

	for i := 0; i < len(planStrings); i++ {
		fmt.Print("P", i, " ")
		fmt.Println(planStrings[i])
		waitTime += calcWaitTime(planStrings[i])
		fullExecTime += calcFullRunTime(planStrings[i])
	}

	fmt.Println(strings.Repeat("=", separatorlength))
	fmt.Println("Время ожидания:", waitTime)
	fmt.Println("Время исполнения:", maxLen)
	fmt.Println("Среднее время ожидания:", waitTime/length)
	fmt.Println("Среднее время исполнения:", fullExecTime/length)
	fmt.Println(strings.Repeat("=", separatorlength))
}

func calcBestRRQuantAndTime(planOriginal map[int]int, maxQuant int) (int, float32) {
	bestQuantCount := 1
	var smallestAvgWaitTime float32 = -1

	for quantCount := 1; quantCount <= maxQuant; quantCount++ {
		var waitTime float32 = 0
		plan := make(map[int]int, len(planOriginal))
		for i, v := range planOriginal {
			plan[i] = v
		}

		planStrings := make(map[int]string, len(plan))
		maxLen := 0

		for len(plan) != 0 {
			keys := make([]int, 0, len(plan))
			for key := range plan {
				keys = append(keys, key)
			}

			sort.SliceStable(keys, func(i, j int) bool {
				return keys[i] < keys[j]
			})

			for _, key := range keys {
				if plan[key] > quantCount {
					planStrings[key] += strings.Repeat("+", quantCount)
					for k := range plan {
						if k != key {
							planStrings[k] += strings.Repeat("-", quantCount)
						}
					}

					plan[key] -= quantCount
				} else {
					planStrings[key] += strings.Repeat("+", plan[key])
					for k := range plan {
						if k != key {
							planStrings[k] += strings.Repeat("-", plan[key])
						}
					}

					delete(plan, key)
				}

				maxLen = len(planStrings[key])
			}
		}

		for key := range planStrings {
			planStrings[key] += strings.Repeat("-", maxLen-len(planStrings[key]))
		}

		for i := 0; i < len(planStrings); i++ {
			waitTime += float32(calcWaitTime(planStrings[i]))
		}

		if waitTime/float32(len(planOriginal)) < smallestAvgWaitTime || smallestAvgWaitTime == -1 {
			smallestAvgWaitTime = waitTime / float32(len(planOriginal))
			bestQuantCount = quantCount
		}
	}

	return bestQuantCount, smallestAvgWaitTime
}

func calcWaitTime(planString string) float32 {
	lastPlus := 0

	for i, v := range planString {
		if v == '+' {
			lastPlus = i
		}
	}

	return float32(strings.Count(planString[0:lastPlus], "-"))
}

func calcFullRunTime(planString string) float32 {
	lastPlus := 0

	for i, v := range planString {
		if v == '+' {
			lastPlus = i
		}
	}

	return float32(lastPlus + 1)
}

func SJF(plan map[int]int) {
	var fullExecTime float32 = 0
	var waitTime float32 = 0
	separatorlength := GetSeparatorLength(plan)
	keys := make([]int, 0, len(plan))
	execTime := 0

	fmt.Println(strings.Repeat("=", separatorlength))
	fmt.Println("SJF")
	fmt.Println(strings.Repeat("=", separatorlength))

	for key := range plan {
		keys = append(keys, key)
	}

	sort.SliceStable(keys, func(i, j int) bool {
		return plan[keys[i]] < plan[keys[j]]
	})

	for i, v := range keys {
		fmt.Print("P", keys[i], " ")

		planString := ""

		execTime += plan[v]
		for j := 0; j < i; j++ {
			waitTime += float32(plan[keys[j]])
			planString += strings.Repeat("-", plan[keys[j]])
		}

		planString += strings.Repeat("+", plan[v])

		for j := i + 1; j < len(plan); j++ {
			planString += strings.Repeat("-", plan[keys[j]])
		}

		fullExecTime += calcFullRunTime(planString)
		fmt.Println(planString)
	}

	fmt.Println(strings.Repeat("=", separatorlength))
	fmt.Println("Время ожидания:", waitTime)
	fmt.Println("Время исполнения:", execTime)
	fmt.Println("Среднее время ожидания:", waitTime/float32(len(plan)))
	fmt.Println("Среднее время исполнения:", fullExecTime/float32(len(plan)))
}

func ReadString(scanner *bufio.Scanner) (string, error) {
	if !scanner.Scan() {
		return "", errors.New("")
	}

	if err := scanner.Err(); err != nil {
		return "", err
	}

	return scanner.Text(), nil
}

func ReadInt(scanner *bufio.Scanner) (int, error) {
	if !scanner.Scan() {
		return 0, errors.New("")
	}

	if err := scanner.Err(); err != nil {
		return 0, err
	}

	return strconv.Atoi(scanner.Text())
}

func SliceContains(slice []string, str string) bool {
	for _, v := range slice {
		if str == v {
			return true
		}
	}

	return false
}
